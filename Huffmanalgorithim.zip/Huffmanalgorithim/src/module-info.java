/**
 * 
 */
/**
 * @author lenovo
 *
 */
module Huffmanalgorithim {
}