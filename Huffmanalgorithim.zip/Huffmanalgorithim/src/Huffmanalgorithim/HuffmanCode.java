package Huffmanalgorithim;
//main class
import java.util.*;
import java.io.*;
public class HuffmanCode {
    public static void createHuffmanTree(String text) throws IOException {
    	File file1=new File("out.txt");
    	FileWriter fw=new FileWriter(file1);
    	PrintWriter pw=new PrintWriter(fw);
    	pw.println("sizeof original text: =" + ((text.length())*8));
        if (text == null || text.length() == 0) {
            return;
        }
        //store frequancy
        Map<Character, Integer> freq = new HashMap<>();
        for (char ch : text.toCharArray()) {
            //calculate freq for each character 
            freq.put(ch, freq.getOrDefault(ch, 0) + 1);
        }
        //create a priority queue that stores current nodes of the Huffman tree.
        //and compare frequancy
        PriorityQueue<Node> q = new PriorityQueue<>(Comparator.comparingInt(l -> l.freq));
        for (var entry : freq.entrySet()) {
            //creates a leaf node and add it to the queue
            q.add(new Node(entry.getKey(), entry.getValue()));
        }
        while (q.size() != 1) {
            //removing the nodes 
            Node left = q.poll();
            Node right = q.poll();
            //sum freq of tow node
            int sum = left.freq + right.freq;
            //adding a new internal node (deleted nodes i.e. right and left) to the queue with a frequency that is equal to the sum of both nodes
            q.add(new Node(null, sum, left, right));
        }
        //used to retrieve or fetch the first element of the Queue or the element present at the head of the Queue
        Node root = q.peek();
        //map to store character and code of character
        Map<Character, String> huffmanCode = new HashMap<>();
        encodeData(root, "", huffmanCode);
        //print the Huffman codes for the characters
        pw.println("Huffman Codes of the characters are: " + huffmanCode);
        //prints the original data
       pw.println("The initial string is: " + text);
        //creating empty object.. very much similar to the StringBuffer class,
        StringBuilder obj = new StringBuilder();
        //loop iterate over the character array
        for (char c : text.toCharArray()) {
            //prints encoded string by getting characters
            obj.append(huffmanCode.get(c));
           
        }
        //calculate encoded size of huffman code
        int sum=0;
        ArrayList<Integer> e1=new ArrayList<Integer>();
        ArrayList<Integer> e2=new ArrayList<Integer>();
        for (Map.Entry<Character, String> set :
        	huffmanCode.entrySet()) {
        	String n=set.getValue();
                             e1.add(n.length());
                             //System.out.println(set.getValue());
                
                             
       }
        for (Map.Entry<Character, Integer> set :
        	freq.entrySet()) {
    
                             e2.add(set.getValue());
                            // System.out.println(set.getValue());
                             
       }
        for (int i=0;i<e1.size();i++) {
    
              sum+=e1.get(i)*e2.get(i);
       }
 
        pw.println("The encoded string is: " + obj);
        pw.println("the size after encoded = "+sum);
        pw.print("The decoded string is: ");
        
        if (isLeaf(root)) {
            //special case: a, aa, aaa, 
            while (root.freq-- > 0) {
               pw.print(root.data);
            }
        } else {
                        int index = -1;
            while (index < obj.length() - 1) {
                index = decodeData(root, index, obj,fw,pw);
            }
        }
        pw.close();
   
    }

    //function that encodes the data
    public static void encodeData(Node root, String str, Map<Character, String> huffmanCode) {
        if (root == null) {
            return;
        }
        //checks if the node is a leaf node or not
        if (isLeaf(root)) {
            huffmanCode.put(root.data, str.length() > 0 ? str : "1");
        }
        encodeData(root.left, str + '0', huffmanCode);
        encodeData(root.right, str + '1', huffmanCode);
    }

    public static int decodeData(Node root, int index, StringBuilder sb,FileWriter fw,PrintWriter pw) throws IOException {
        //checks if the root node is null or not
        if (root == null) {
            return index;
        }
        //checks if the node is a leaf node or not
        if (isLeaf(root)) {
          pw.print(root.data);
            return index;
        }
        index++;
        root = (sb.charAt(index) == '0') ? root.left : root.right;
        index = decodeData(root, index, sb,fw,pw);
       // pw.close();
        return index;
    }

    //if the Huffman Tree contains a single node
    public static boolean isLeaf(Node root) {
        return root.left == null && root.right == null;
    }

    
    public static void main(String args[]) throws IOException{
       
        File file=new File("input.txt");
        try (Scanner s = new Scanner(file)) {
			String text = "";
      
			     text+=s.next();
			createHuffmanTree(text);
		}
    }
}
class Node
{
    Character data;
    Integer freq;
    Node left = null;
    Node right = null;
    Node(Character data, Integer freq)
    {
        this.data = data;
        this.freq = freq;
    }
    public Node(Character data, Integer freq, Node left, Node right)
    {
        this.data = data;
        this.freq = freq;
        this.left = left;
        this.right = right;
    }
}

